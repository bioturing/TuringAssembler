#include <stdio.h>
//#include <ext/algorithm>
#include <iostream>
using namespace std;
