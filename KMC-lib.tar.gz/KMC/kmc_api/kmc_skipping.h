#ifndef _KMC_SKIPPING_H_
#define _KMC_SKIPPING_H_

#include "../../src/asm_hash.h"

#ifdef __cplusplus
extern "C" {
#endif

int KMC_slave_kmer_count(int ksize, const char *working_dir, int n_threads,
			int mmem, int n_files, char **files, void *table,
			void (*kmhash_insert)(void *, const char *, int));

int KMC_arg_kmer_count(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif
