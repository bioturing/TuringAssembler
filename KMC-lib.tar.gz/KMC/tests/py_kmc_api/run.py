#!/usr/bin/env python3
import subprocess, sys, os
#print(os.path.dirname(os.path.abspath(__file__)))
#sys.path.append(os.path.dirname(os.path.abspath(__file__)))
subprocess.call(['python3', '-m', 'pytest'])
#subprocess.call(['pytest'])
